export interface Product {
  id: number;
  name: string;
  supermarket: string;
  url: string;
  date: any;
  price: any;
  content: any;
}
