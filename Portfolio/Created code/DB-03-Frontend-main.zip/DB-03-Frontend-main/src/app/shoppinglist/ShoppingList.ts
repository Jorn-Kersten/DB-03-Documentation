export interface ShoppingList {
  id: number;
  productListId: number;
  name: string;
  superMarket: string;
  date: any;
  totalPrice: any;
}
