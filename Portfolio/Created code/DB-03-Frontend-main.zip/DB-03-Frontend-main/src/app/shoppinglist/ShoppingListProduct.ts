export interface ShoppingListProduct {
  id: number;
  shoppingListId: number;
  userName: string;
  quantity: number;
  content: any;
  name: string;
  superMarket: string;
  url: string;
  date: any;
  price: any;
}
