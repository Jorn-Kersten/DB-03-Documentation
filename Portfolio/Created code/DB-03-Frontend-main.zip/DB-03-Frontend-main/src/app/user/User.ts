export interface User {
  id: number | undefined;
  name: string | undefined;
  email: string | undefined;
}
